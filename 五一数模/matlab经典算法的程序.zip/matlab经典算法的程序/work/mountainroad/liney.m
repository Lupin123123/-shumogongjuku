function x=liney(y,a,endp)
x=(endp(1)-a(1))*(y-endp(2))/(endp(2)-a(2))+endp(1);

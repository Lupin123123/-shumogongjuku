function y=linex(x,a,endp)
y=(endp(2)-a(2))*(x-endp(1))/(endp(1)-a(1))+endp(2);

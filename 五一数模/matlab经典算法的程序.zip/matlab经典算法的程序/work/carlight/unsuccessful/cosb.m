function y=cosb(x0,y0,z0,x,y)
z=25000;
y=(2*x0*(x-x0)+2*y0*(y-y0)-60*(z-z0))/sqrt(((x-x0)^2+(y-y0)^2+(z-z0)^2)*(4*x0^2+4*y0^2+3600));
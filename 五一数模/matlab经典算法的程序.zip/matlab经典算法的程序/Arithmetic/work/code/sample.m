function y=sample(varargin)
varargin{:}
y=0;
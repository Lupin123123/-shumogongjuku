function main
r=mrank(5);
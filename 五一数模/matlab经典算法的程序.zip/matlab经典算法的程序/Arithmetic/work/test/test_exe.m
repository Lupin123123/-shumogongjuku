function [out]=test_exe()
out=100*188*sqrt(100);
disp('out=');
disp(out);
--------------------Configuration: matcreat - Win32 Debug--------------------
Compiling...
matcreat.c
d:\work\c_mat\matcreat.c(4) : fatal error C1083: Cannot open include file: 'mat.h': No such file or directory
Error executing cl.exe.

matcreat.exe - 1 error(s), 0 warning(s)

x0=0;
n=100;
[x,k]=newton1(x0,n);
x
k

a=3;
b=4;
[x,k]=erfenfa(a,b);
x
k
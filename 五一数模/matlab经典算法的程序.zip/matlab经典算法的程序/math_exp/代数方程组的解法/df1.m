function b=df1(x)
b=zeros(1,1);
b=2*x+1;
function f=f1(x);
f=zeros(1,1);
f=x^2+x-14;

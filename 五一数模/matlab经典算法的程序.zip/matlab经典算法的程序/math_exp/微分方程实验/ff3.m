      [x,y,z]=dsolve('Dx=2*x-3*y+3*z','Dy=4*x-5*y+3*z','Dz=4*x-4*y+2*z','t');
        x=simple(x)         
       y=simple(y)
       z=simple(z)